local QBCore = exports['qb-core']:GetCoreObject()

-----------------------------
--   GIVE RAW MATERIALS
-----------------------------
RegisterNetEvent("faubillet:giveRaw", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    Player.Functions.AddItem("raw_faubillet", 1)
    TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["raw_faubillet"], "add")
end)

-----------------------------
--   CRAFT FAKE BILLS
-----------------------------
RegisterNetEvent("faubillet:craftBills", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    if Player.Functions.RemoveItem("raw_faubillet", 1) then
        Player.Functions.AddItem("faubillet", 1)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["faubillet"], "add")
    else
        TriggerClientEvent('QBCore:Notify', src, "Tu n'as pas les matières premières !", "error")
    end
end)

-----------------------------
--   PACKAGING
-----------------------------
RegisterNetEvent("faubillet:packBills", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    if Player.Functions.RemoveItem("faubillet", 1) then
        Player.Functions.AddItem("pack_faubillet", 1)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items["pack_faubillet"], "add")
    else
        TriggerClientEvent('QBCore:Notify', src, "Aucun faux billet à emballer !", "error")
    end
end)

-----------------------------
--   SELL PACKAGED BILLS
-----------------------------
RegisterNetEvent("faubillet:finishSell", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    if Player.Functions.RemoveItem("pack_faubillet", 1) then
        Player.Functions.AddMoney("cash", Config.Reward)
        TriggerClientEvent('QBCore:Notify', src, "+ $" .. Config.Reward .. " gagnés !", "success")
    else
        TriggerClientEvent('QBCore:Notify', src, "Tu n'as aucun pack de faux billets !", "error")
    end
end)
