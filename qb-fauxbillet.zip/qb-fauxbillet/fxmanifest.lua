fx_version 'cerulean'
game 'gta5'

author 'Mr Full'
description 'Système de Faux Billets pour QBCore'
version '1.0.0'

shared_scripts {
    '@qb-core/shared.lua',
    'config.lua'
}

client_script 'client.lua'
server_script 'server.lua'
