Config = {}

-- Récompense par vente terminée
Config.Reward = 50000

-- Positions
Config.Positions = {
    RawMaterials = vector4(1129.6771, -3194.1663, -40.3966, 359.9015),
    Fabrication  = vector4(1131.3348, -3197.2661, -39.6657, 174.0276),
    Packaging    = vector4(1116.7155, -3195.6152, -40.4015, 87.9447),
    StartSelling = vector4(1138.2395, -3193.7612, -40.3942, 355.5355)
}

-- Zones aléatoires de vente
Config.SellZones = {
    vector4(-2296.4060, 380.9880, 174.4667, 303.5126),
    vector4(1268.5925, -1739.1309, 50.7777, 116.2884),
    vector4(1412.3649, 6535.0220, 16.7254, 42.4578)
}
