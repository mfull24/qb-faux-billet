local QBCore = exports['qb-core']:GetCoreObject()
local CurrentSellLocation = nil
local Selling = false

------------------------------------
-- RESTRICTION DE JOBS 
------------------------------------
local function IsFamilly()
    local PlayerData = QBCore.Functions.GetPlayerData()
    return PlayerData.job and PlayerData.job.name == "familly"
end

----------------------------
--      QB-TARGET
----------------------------

CreateThread(function()
    -- Matières premières
    exports['qb-target']:AddCircleZone("faubillet_raw", Config.Positions.RawMaterials.xyz, 1.2, {
        name="faubillet_raw",
    }, {
        options = {
            {
                event = "faubillet:getraw",
                icon = "fas fa-box",
                label = "Récupérer les matières premières",
                canInteract = function()
                    return IsFamilly()
                end
            }
        },
        distance = 2.0
    })

    -- Fabrication
    exports['qb-target']:AddCircleZone("faubillet_fab", Config.Positions.Fabrication.xyz, 1.2, {
        name="faubillet_fab",
    }, {
        options = {
            {
                event = "faubillet:craft",
                icon = "fas fa-cog",
                label = "Fabriquer les faux billets",
                canInteract = function()
                    return IsFamilly()
                end
            }
        },
        distance = 2.0
    })

    -- Packaging
    exports['qb-target']:AddCircleZone("faubillet_pack", Config.Positions.Packaging.xyz, 1.2, {
        name="faubillet_pack",
    }, {
        options = {
            {
                event = "faubillet:pack",
                icon = "fas fa-box-open",
                label = "Mettre en emballage",
                canInteract = function()
                    return IsFamilly()
                end
            }
        },
        distance = 2.0
    })

    -- Lancement vente
    exports['qb-target']:AddCircleZone("faubillet_sellstart", Config.Positions.StartSelling.xyz, 1.2, {
        name="faubillet_sellstart",
    }, {
        options = {
            {
                event = "faubillet:startselling",
                icon = "fas fa-dollar-sign",
                label = "Lancer la vente",
                canInteract = function()
                    return IsFamilly()
                end
            }
        },
        distance = 2.0
    })
end)

----------------------------
--  EVENTS CLIENT
----------------------------

RegisterNetEvent("faubillet:getraw", function()
    if not IsFamilly() then
        QBCore.Functions.Notify("Accès refusé : réservé au gang Familly.", "error")
        return
    end

    QBCore.Functions.Progressbar("raw", "Récupération...", 5000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableCombat = true,
    }, {}, {}, {}, function()
        TriggerServerEvent("faubillet:giveRaw")
    end)
end)

RegisterNetEvent("faubillet:craft", function()
    if not IsFamilly() then
        QBCore.Functions.Notify("Accès refusé : réservé au gang Familly.", "error")
        return
    end

    QBCore.Functions.Progressbar("craft", "Fabrication des faux billets...", 7000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableCombat = true,
    }, {}, {}, {}, function()
        TriggerServerEvent("faubillet:craftBills")
    end)
end)

RegisterNetEvent("faubillet:pack", function()
    if not IsFamilly() then
        QBCore.Functions.Notify("Accès refusé : réservé au gang Familly.", "error")
        return
    end

    QBCore.Functions.Progressbar("pack", "Mise en packtage...", 6000, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableCombat = true,
    }, {}, {}, {}, function()
        TriggerServerEvent("faubillet:packBills")
    end)
end)

RegisterNetEvent("faubillet:startselling", function()
    if not IsFamilly() then
        QBCore.Functions.Notify("Accès refusé : réservé au gang Familly.", "error")
        return
    end

    if Selling then
        QBCore.Functions.Notify("Tu es déjà en cours de vente !", "error")
        return
    end

    TriggerEvent("faubillet:chooseSellZone")
end)

-- Choix d'une zone aléatoire
RegisterNetEvent("faubillet:chooseSellZone", function()
    if not IsFamilly() then
        QBCore.Functions.Notify("Accès refusé : réservé au gang Familly.", "error")
        return
    end

    local randomZone = Config.SellZones[math.random(#Config.SellZones)]
    CurrentSellLocation = randomZone
    Selling = true

    QBCore.Functions.Notify("Rends-toi au point de vente indiqué !", "success")

    SetNewWaypoint(CurrentSellLocation.x, CurrentSellLocation.y)

    CreateThread(function()
        while Selling do
            local ped = PlayerPedId()
            local pos = GetEntityCoords(ped)

            if #(pos - vector3(CurrentSellLocation.x, CurrentSellLocation.y, CurrentSellLocation.z)) < 2.0 then
                QBCore.Functions.Progressbar("sell", "Vente en cours...", 8000, false, true, {
                    disableMovement = true,
                    disableCarMovement = true,
                    disableCombat = true,
                }, {}, {}, {}, function()
                    TriggerServerEvent("faubillet:finishSell")
                    Selling = false
                end)
            end

            Wait(500)
        end
    end)
end)
